require("dotenv").config()
const mysql = require("mysql2/promise")

async function testDatabase() {
  console.log("=== TESTANDO CONEXÃO E OPERAÇÕES DO BANCO ===")

  try {
    // Conectar ao banco
    const db = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "",
      database: process.env.DB_NAME || "santoros_restaurant",
    })

    console.log("✅ Conectado ao banco de dados")

    // Testar inserção de reserva
    console.log("\n1. Testando inserção de reserva...")
    try {
      const [result] = await db.execute(
        `INSERT INTO reservations (name, email, phone, date, time, guests, special_requests, status) 
         VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')`,
        ["João Silva", "joao@teste.com", "(11) 99999-9999", "2024-01-20", "19:00", 4, "Mesa próxima à janela"],
      )
      console.log("✅ Reserva inserida com ID:", result.insertId)
    } catch (error) {
      console.error("❌ Erro ao inserir reserva:", error.message)
    }

    // Verificar reservas
    console.log("\n2. Verificando reservas no banco...")
    const [reservations] = await db.execute("SELECT * FROM reservations ORDER BY id DESC LIMIT 5")
    console.log(`Encontradas ${reservations.length} reservas:`)
    reservations.forEach((res) => {
      console.log(`   - ID: ${res.id}, Nome: ${res.name}, Data: ${res.date}, Status: ${res.status}`)
    })

    // Testar inserção de usuário
    console.log("\n3. Testando inserção de usuário...")
    try {
      const bcrypt = require("bcrypt")
      const hashedPassword = await bcrypt.hash("123456789", 10)
      const [result] = await db.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", [
        "Maria Santos",
        "maria@teste.com",
        hashedPassword,
      ])
      console.log("✅ Usuário inserido com ID:", result.insertId)
    } catch (error) {
      console.error("❌ Erro ao inserir usuário:", error.message)
    }

    // Verificar usuários
    console.log("\n4. Verificando usuários no banco...")
    const [users] = await db.execute("SELECT id, name, email, created_at FROM users ORDER BY id DESC LIMIT 5")
    console.log(`Encontrados ${users.length} usuários:`)
    users.forEach((user) => {
      console.log(`   - ID: ${user.id}, Nome: ${user.name}, Email: ${user.email}`)
    })

    // Verificar estrutura das tabelas
    console.log("\n5. Verificando estrutura das tabelas...")
    const tables = ["users", "reservations", "menu_items", "inventory"]

    for (const table of tables) {
      const [columns] = await db.execute(`DESCRIBE ${table}`)
      console.log(`\nTabela ${table}:`)
      columns.forEach((col) => {
        console.log(`   - ${col.Field}: ${col.Type} ${col.Null === "NO" ? "NOT NULL" : "NULL"}`)
      })
    }

    await db.end()
    console.log("\n✅ TESTE CONCLUÍDO COM SUCESSO!")
  } catch (error) {
    console.error("\n❌ ERRO NO TESTE:", error.message)
    console.error("Stack:", error.stack)
  }
}

testDatabase().catch(console.error)
