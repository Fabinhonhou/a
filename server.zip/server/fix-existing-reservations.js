require("dotenv").config()
const mysql = require("mysql2/promise")

async function fixExistingReservations() {
  console.log("=== CORRIGINDO RESERVAS EXISTENTES ===")

  try {
    // Conectar ao banco de dados
    const db = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "MYdatabase@2025",
      database: process.env.DB_NAME || "santoros_restaurant",
    })

    console.log("✅ Conectado ao banco de dados")

    // Buscar reservas sem user_id
    const [orphanReservations] = await db.execute("SELECT * FROM reservations WHERE user_id IS NULL")

    console.log(`Encontradas ${orphanReservations.length} reservas sem user_id`)

    if (orphanReservations.length === 0) {
      console.log("✅ Nenhuma reserva órfã encontrada!")
      return
    }

    // Buscar usuários
    const [users] = await db.execute("SELECT id, email FROM users")

    console.log("Usuários disponíveis:")
    users.forEach((user, index) => {
      console.log(`${index + 1}. ID: ${user.id}, Email: ${user.email}`)
    })

    // Para cada reserva órfã, tentar associar a um usuário pelo email
    for (const reservation of orphanReservations) {
      console.log(`\nProcessando reserva ID ${reservation.id} (${reservation.email})`)

      // Procurar usuário com o mesmo email
      const matchingUser = users.find((user) => user.email === reservation.email)

      if (matchingUser) {
        console.log(`  ✅ Encontrado usuário correspondente: ID ${matchingUser.id}`)

        // Atualizar a reserva
        await db.execute("UPDATE reservations SET user_id = ? WHERE id = ?", [matchingUser.id, reservation.id])

        console.log(`  ✅ Reserva ${reservation.id} associada ao usuário ${matchingUser.id}`)
      } else {
        console.log(`  ⚠️ Nenhum usuário encontrado com email ${reservation.email}`)
        console.log(`  💡 Você pode criar uma conta com este email ou associar manualmente`)
      }
    }

    // Verificar resultado
    const [updatedReservations] = await db.execute("SELECT COUNT(*) as count FROM reservations WHERE user_id IS NULL")
    console.log(`\n📊 Reservas ainda sem user_id: ${updatedReservations[0].count}`)

    // Mostrar estatísticas por usuário
    const [userStats] = await db.execute(`
      SELECT u.id, u.email, COUNT(r.id) as reservation_count
      FROM users u
      LEFT JOIN reservations r ON u.id = r.user_id
      GROUP BY u.id, u.email
      ORDER BY reservation_count DESC
    `)

    console.log("\n📊 ESTATÍSTICAS POR USUÁRIO:")
    userStats.forEach((stat) => {
      console.log(`  - ${stat.email}: ${stat.reservation_count} reservas`)
    })

    await db.end()
    console.log("\n✅ CORREÇÃO CONCLUÍDA!")
  } catch (error) {
    console.error("\n❌ ERRO:", error.message)
  }
}

fixExistingReservations().catch(console.error)
