require("dotenv").config()
const jwt = require("jsonwebtoken")

const JWT_SECRET = process.env.JWT_SECRET || "b6203381221684dfc0504aa5bfeaa9e06ed7434ba146f02c54480b45ad785180"

async function testReservationsAPI() {
  console.log("=== TESTANDO API DE RESERVAS ===")

  try {
    // Simular um usuário logado (use o ID de um usuário real)
    const userId = 1 // Ajuste conforme necessário
    const token = jwt.sign({ userId: userId, email: "test@example.com" }, JWT_SECRET, { expiresIn: "7d" })

    console.log("Token gerado:", token)
    console.log("User ID:", userId)

    // Testar GET /api/reservations
    console.log("\n1. TESTANDO GET /api/reservations")

    const response = await fetch("http://localhost:3000/api/reservations", {
      method: "GET",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    })

    console.log("Status:", response.status)
    console.log("Headers:", Object.fromEntries(response.headers.entries()))

    if (response.ok) {
      const data = await response.json()
      console.log("Resposta:", JSON.stringify(data, null, 2))
    } else {
      const errorText = await response.text()
      console.log("Erro:", errorText)
    }

    // Testar POST /api/reservations
    console.log("\n2. TESTANDO POST /api/reservations")

    const tomorrow = new Date()
    tomorrow.setDate(tomorrow.getDate() + 1)
    const tomorrowStr = tomorrow.toISOString().split("T")[0]

    const reservationData = {
      name: "Teste API",
      email: "teste@api.com",
      phone: "(555) 999-8888",
      date: tomorrowStr,
      time: "20:00",
      guests: 3,
      specialRequests: "Teste via API",
    }

    const postResponse = await fetch("http://localhost:3000/api/reservations", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(reservationData),
    })

    console.log("Status POST:", postResponse.status)

    if (postResponse.ok) {
      const postData = await postResponse.json()
      console.log("Reserva criada:", JSON.stringify(postData, null, 2))
    } else {
      const postErrorText = await postResponse.text()
      console.log("Erro POST:", postErrorText)
    }
  } catch (error) {
    console.error("❌ ERRO NO TESTE:", error.message)
  }
}

// Aguardar um pouco para o servidor estar rodando
setTimeout(() => {
  testReservationsAPI().catch(console.error)
}, 2000)
