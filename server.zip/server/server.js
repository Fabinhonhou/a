require("dotenv").config()

const express = require("express")
const mysql = require("mysql2/promise")
const bcrypt = require("bcrypt")
const jwt = require("jsonwebtoken")
const cors = require("cors")
const path = require("path")

const app = express()
const PORT = process.env.PORT || 3000
const JWT_SECRET = process.env.JWT_SECRET || "b6203381221684dfc0504aa5bfeaa9e06ed7434ba146f02c54480b45ad785180"

// Middleware
app.use(cors())
app.use(express.json())

// Log de todas as requisições para debug
app.use((req, res, next) => {
  console.log(`${new Date().toISOString()} - ${req.method} ${req.url}`)
  next()
})

// Configuração mais específica para arquivos estáticos
const staticPath = path.join(__dirname, "../")
console.log("📁 Serving static files from:", staticPath)

// Servir arquivos estáticos com configuração específica
app.use(
  express.static(staticPath, {
    setHeaders: (res, path) => {
      if (path.endsWith(".js")) {
        res.setHeader("Content-Type", "application/javascript")
      }
      if (path.endsWith(".css")) {
        res.setHeader("Content-Type", "text/css")
      }
    },
  }),
)

// Database configuration
const dbConfig = {
  host: process.env.DB_HOST || "localhost",
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "MYdatabase@2025",
  database: process.env.DB_NAME || "santoros_restaurant",
}

// Database connection
let db

async function initDatabase() {
  try {
    console.log("=== INICIALIZANDO BANCO DE DADOS ===")
    console.log("Host:", dbConfig.host)
    console.log("Port:", dbConfig.port)
    console.log("User:", dbConfig.user)
    console.log("Database:", dbConfig.database)

    // Primeiro, conectar sem especificar banco de dados para criá-lo se necessário
    console.log("1. Conectando sem especificar banco de dados...")
    const tempConnection = await mysql.createConnection({
      host: dbConfig.host,
      port: dbConfig.port,
      user: dbConfig.user,
      password: dbConfig.password,
    })

    // Criar o banco de dados se não existir
    const dbName = dbConfig.database
    console.log(`2. Criando banco de dados "${dbName}" se não existir...`)
    await tempConnection.execute(`CREATE DATABASE IF NOT EXISTS ${dbName}`)
    await tempConnection.end()
    console.log("   ✅ Banco de dados verificado/criado")

    // Agora conectar diretamente ao banco específico
    console.log("3. Conectando ao banco específico...")
    db = await mysql.createConnection(dbConfig)
    console.log("   ✅ Conectado ao MySQL database com sucesso!")

    // Criar tabelas se não existirem
    console.log("4. Verificando/criando tabelas...")
    await createTables()
    console.log("   ✅ Tabelas verificadas/criadas com sucesso!")

    console.log("=== BANCO DE DADOS INICIALIZADO COM SUCESSO ===\n")
  } catch (error) {
    console.error("❌ Falha na conexão com o banco de dados:", error.message)
    console.log("\nDicas de solução:")
    console.log("1. Verifique se o MySQL está rodando na porta 3306")
    console.log("2. Confirme o usuário e senha do MySQL")
    console.log("3. Verifique o arquivo .env")
    console.log("4. Execute: node server/create-db-fixed.js")
    process.exit(1)
  }
}

async function createTables() {
  try {
    // Users table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Reservations table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS reservations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        date DATE NOT NULL,
        time VARCHAR(10) NOT NULL,
        guests INT NOT NULL,
        special_requests TEXT,
        status ENUM('pending', 'confirmed', 'cancelled') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_user_id (user_id),
        INDEX idx_date (date),
        INDEX idx_status (status)
      )
    `)

    // Menu items table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS menu_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(10, 2) NOT NULL,
        category VARCHAR(100) NOT NULL,
        image_url VARCHAR(500),
        available BOOLEAN DEFAULT TRUE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_category (category),
        INDEX idx_available (available)
      )
    `)

    // Inventory table
    await db.execute(`
      CREATE TABLE IF NOT EXISTS inventory (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        category VARCHAR(100) NOT NULL,
        current_stock DECIMAL(10, 2) NOT NULL DEFAULT 0,
        min_stock DECIMAL(10, 2) NOT NULL DEFAULT 0,
        unit VARCHAR(50) NOT NULL,
        supplier VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_category (category),
        INDEX idx_stock_level (current_stock, min_stock)
      )
    `)

    console.log("   - Todas as tabelas foram verificadas/criadas")
  } catch (error) {
    console.error("Erro ao criar tabelas:", error)
    throw error
  }
}

// Authentication middleware
function authenticateToken(req, res, next) {
  console.log("🔐 Verificando autenticação para:", req.url)

  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  console.log("Token presente:", token ? "Sim" : "Não")

  if (!token) {
    console.log("❌ Token não fornecido")
    return res.status(401).json({ message: "Access token required" })
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      console.log("❌ Token inválido:", err.message)
      return res.status(403).json({ message: "Invalid token" })
    }
    console.log("✅ Token válido para usuário:", user.userId)
    req.user = user
    next()
  })
}

// Middleware opcional de autenticação (para reservas de usuários não logados)
function optionalAuth(req, res, next) {
  console.log("🔐 Verificando autenticação opcional para:", req.url)

  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (token) {
    jwt.verify(token, JWT_SECRET, (err, user) => {
      if (!err) {
        console.log("✅ Token válido encontrado para usuário:", user.userId)
        req.user = user
      } else {
        console.log("⚠️ Token inválido, continuando sem autenticação")
      }
      next()
    })
  } else {
    console.log("⚠️ Nenhum token fornecido, continuando sem autenticação")
    next()
  }
}

// Routes

// User Registration
app.post("/api/register", async (req, res) => {
  try {
    const { name, email, password } = req.body

    // Validate input
    if (!name || !email || !password) {
      return res.status(400).json({ message: "All fields are required" })
    }

    if (password.length < 8) {
      return res.status(400).json({ message: "Password must be at least 8 characters long" })
    }

    // Check if user already exists
    const [existingUsers] = await db.execute("SELECT id FROM users WHERE email = ?", [email])

    if (existingUsers.length > 0) {
      return res.status(400).json({ message: "Email already in use" })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create user
    const [result] = await db.execute("INSERT INTO users (name, email, password) VALUES (?, ?, ?)", [
      name,
      email,
      hashedPassword,
    ])

    res.status(201).json({
      success: true,
      message: "User created successfully",
      userId: result.insertId,
    })
  } catch (error) {
    console.error("Registration error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// User Login
app.post("/api/login", async (req, res) => {
  try {
    const { email, password } = req.body

    // Validate input
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" })
    }

    // Find user - incluindo a data de criação
    const [users] = await db.execute("SELECT id, name, email, password, created_at FROM users WHERE email = ?", [email])

    if (users.length === 0) {
      return res.status(401).json({ message: "Invalid email or password" })
    }

    const user = users[0]

    // Verify password
    const passwordMatch = await bcrypt.compare(password, user.password)

    if (!passwordMatch) {
      return res.status(401).json({ message: "Invalid email or password" })
    }

    // Generate JWT token
    const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" })

    console.log("✅ Login bem-sucedido para:", user.email)

    res.json({
      success: true,
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        created_at: user.created_at, // Incluindo a data de criação
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Get User Profile - Nova rota para buscar dados do usuário
app.get("/api/user/profile", authenticateToken, async (req, res) => {
  try {
    console.log("📋 Buscando perfil do usuário:", req.user.userId)

    const [users] = await db.execute("SELECT id, name, email, created_at FROM users WHERE id = ?", [req.user.userId])

    if (users.length === 0) {
      console.log("❌ Usuário não encontrado:", req.user.userId)
      return res.status(404).json({ message: "User not found" })
    }

    const user = users[0]
    console.log("✅ Perfil encontrado:", user.email)

    res.json({
      success: true,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        created_at: user.created_at,
      },
    })
  } catch (error) {
    console.error("Get user profile error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Create Reservation - CORRIGIDO para usar autenticação opcional
app.post("/api/reservations", optionalAuth, async (req, res) => {
  try {
    console.log("📝 Recebendo nova reserva:", req.body)
    console.log("👤 Usuário autenticado:", req.user ? `ID: ${req.user.userId}` : "Não autenticado")

    const { name, email, phone, date, time, guests, specialRequests } = req.body
    const userId = req.user ? req.user.userId : null

    console.log("🆔 User ID que será salvo:", userId)

    // Validate input
    if (!name || !email || !phone || !date || !time || !guests) {
      return res.status(400).json({ message: "All required fields must be provided" })
    }

    // Validate date is not in the past
    const reservationDate = new Date(date)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (reservationDate < today) {
      return res.status(400).json({ message: "Reservation date cannot be in the past" })
    }

    // Create reservation
    const [result] = await db.execute(
      `INSERT INTO reservations (user_id, name, email, phone, date, time, guests, special_requests, status) 
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
      [userId, name, email, phone, date, time, guests, specialRequests || ""],
    )

    console.log("✅ Reserva criada com ID:", result.insertId)
    console.log("🆔 Associada ao usuário:", userId || "Nenhum usuário")

    res.status(201).json({
      success: true,
      message: "Reservation created successfully",
      reservationId: result.insertId,
    })
  } catch (error) {
    console.error("Reservation creation error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Get User Reservations
app.get("/api/reservations", authenticateToken, async (req, res) => {
  try {
    console.log("📋 Buscando reservas do usuário:", req.user.userId)

    // Verificar se o usuário existe
    const [users] = await db.execute("SELECT id FROM users WHERE id = ?", [req.user.userId])

    if (users.length === 0) {
      console.log("❌ Usuário não encontrado:", req.user.userId)
      return res.status(404).json({ message: "User not found" })
    }

    // Buscar reservas
    const [reservations] = await db.execute(
      `SELECT id, date, time, guests, status, special_requests, created_at 
       FROM reservations 
       WHERE user_id = ? 
       ORDER BY date ASC`,
      [req.user.userId],
    )

    console.log("✅ Encontradas", reservations.length, "reservas para usuário", req.user.userId)

    // Log detalhado das reservas para debug
    if (reservations.length > 0) {
      console.log("Detalhes das reservas:")
      reservations.forEach((res) => {
        console.log(`- ID: ${res.id}, Data: ${res.date}, Hora: ${res.time}, Status: ${res.status}`)
      })
    }

    res.json({
      success: true,
      reservations,
    })
  } catch (error) {
    console.error("Get reservations error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Cancel Reservation
app.put("/api/reservations/:id/cancel", authenticateToken, async (req, res) => {
  try {
    const reservationId = req.params.id

    // Check if reservation belongs to user
    const [reservations] = await db.execute("SELECT id, status FROM reservations WHERE id = ? AND user_id = ?", [
      reservationId,
      req.user.userId,
    ])

    if (reservations.length === 0) {
      return res.status(404).json({ message: "Reservation not found" })
    }

    if (reservations[0].status === "cancelled") {
      return res.status(400).json({ message: "Reservation is already cancelled" })
    }

    // Update reservation status
    await db.execute('UPDATE reservations SET status = "cancelled" WHERE id = ?', [reservationId])

    res.json({
      success: true,
      message: "Reservation cancelled successfully",
    })
  } catch (error) {
    console.error("Cancel reservation error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Get Menu Items
app.get("/api/menu", async (req, res) => {
  try {
    const [menuItems] = await db.execute(
      "SELECT id, name, description, price, category, image_url FROM menu_items WHERE available = TRUE ORDER BY category, name",
    )

    res.json({
      success: true,
      menuItems,
    })
  } catch (error) {
    console.error("Get menu error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Admin Login
app.post("/api/admin/login", async (req, res) => {
  try {
    console.log("🔐 Admin login attempt")
    const { email, password, rememberMe } = req.body

    // Validate input
    if (!email || !password) {
      return res.status(400).json({ message: "Email and password are required" })
    }

    // Find admin user
    const [admins] = await db.execute(
      "SELECT id, name, email, password, role, active FROM admin_users WHERE email = ? AND active = TRUE",
      [email.toLowerCase()],
    )

    if (admins.length === 0) {
      console.log("❌ Admin not found:", email)
      return res.status(401).json({ message: "Invalid email or password" })
    }

    const admin = admins[0]

    // Verify password
    const passwordMatch = await bcrypt.compare(password, admin.password)

    if (!passwordMatch) {
      console.log("❌ Invalid password for admin:", email)
      return res.status(401).json({ message: "Invalid email or password" })
    }

    // Update last login
    await db.execute("UPDATE admin_users SET last_login = NOW() WHERE id = ?", [admin.id])

    // Generate JWT token
    const tokenExpiry = rememberMe ? "30d" : "24h"
    const token = jwt.sign(
      {
        adminId: admin.id,
        email: admin.email,
        role: admin.role,
        type: "admin",
      },
      JWT_SECRET,
      { expiresIn: tokenExpiry },
    )

    console.log("✅ Admin login successful:", admin.email, "Role:", admin.role)

    res.json({
      success: true,
      token,
      admin: {
        id: admin.id,
        name: admin.name,
        email: admin.email,
        role: admin.role,
      },
    })
  } catch (error) {
    console.error("Admin login error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Admin middleware
function authenticateAdmin(req, res, next) {
  console.log("🔐 Verificando autenticação admin para:", req.url)

  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  console.log("Token presente:", token ? "Sim" : "Não")

  if (!token) {
    console.log("❌ Token admin não fornecido")
    return res.status(401).json({ message: "Admin access token required" })
  }

  jwt.verify(token, JWT_SECRET, (err, decoded) => {
    if (err) {
      console.log("❌ Token admin inválido:", err.message)
      return res.status(403).json({ message: "Invalid admin token" })
    }

    // Verificar se é um token de admin
    if (decoded.type !== "admin") {
      console.log("❌ Token não é de admin")
      return res.status(403).json({ message: "Admin access required" })
    }

    console.log("✅ Token admin válido para:", decoded.email, "Role:", decoded.role)
    req.admin = decoded
    next()
  })
}

// Nova rota para obter dados do admin logado
app.get("/api/admin/profile", authenticateAdmin, async (req, res) => {
  try {
    console.log("📋 Buscando perfil do admin:", req.admin.adminId)

    const [admins] = await db.execute(
      "SELECT id, name, email, role, active, created_at, last_login FROM admin_users WHERE id = ?",
      [req.admin.adminId],
    )

    if (admins.length === 0) {
      console.log("❌ Admin não encontrado:", req.admin.adminId)
      return res.status(404).json({ message: "Admin not found" })
    }

    const admin = admins[0]
    console.log("✅ Perfil admin encontrado:", admin.email)

    res.json({
      success: true,
      admin: {
        id: admin.id,
        name: admin.name,
        email: admin.email,
        role: admin.role,
        active: admin.active,
        created_at: admin.created_at,
        last_login: admin.last_login,
      },
    })
  } catch (error) {
    console.error("Get admin profile error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Admin Dashboard Stats
app.get("/api/admin/stats", authenticateAdmin, async (req, res) => {
  try {
    const today = new Date().toISOString().split("T")[0]

    // Get today's reservations
    const [todayReservations] = await db.execute("SELECT COUNT(*) as count FROM reservations WHERE DATE(date) = ?", [
      today,
    ])

    // Get pending reservations
    const [pendingReservations] = await db.execute(
      "SELECT COUNT(*) as count FROM reservations WHERE status = 'pending'",
    )

    // Get total guests today
    const [totalGuests] = await db.execute(
      "SELECT SUM(guests) as total FROM reservations WHERE DATE(date) = ? AND status != 'cancelled'",
      [today],
    )

    // Get low stock items
    const [lowStockItems] = await db.execute("SELECT COUNT(*) as count FROM inventory WHERE current_stock <= min_stock")

    res.json({
      success: true,
      stats: {
        todayReservations: todayReservations[0].count,
        pendingReservations: pendingReservations[0].count,
        totalGuests: totalGuests[0].total || 0,
        lowStockItems: lowStockItems[0].count,
      },
    })
  } catch (error) {
    console.error("Get admin stats error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Get All Reservations (Admin)
app.get("/api/admin/reservations", authenticateAdmin, async (req, res) => {
  try {
    const { dateFilter, statusFilter } = req.query

    let query = "SELECT * FROM reservations WHERE 1=1"
    const params = []

    if (dateFilter && dateFilter !== "all") {
      const today = new Date()
      let dateCondition = ""

      switch (dateFilter) {
        case "today":
          dateCondition = "DATE(date) = CURDATE()"
          break
        case "tomorrow":
          dateCondition = "DATE(date) = DATE_ADD(CURDATE(), INTERVAL 1 DAY)"
          break
        case "week":
          dateCondition = "date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)"
          break
      }

      if (dateCondition) {
        query += ` AND ${dateCondition}`
      }
    }

    if (statusFilter && statusFilter !== "all") {
      query += " AND status = ?"
      params.push(statusFilter)
    }

    query += " ORDER BY date DESC, time DESC"

    const [reservations] = await db.execute(query, params)

    res.json({
      success: true,
      reservations,
    })
  } catch (error) {
    console.error("Get admin reservations error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Update Reservation Status (Admin)
app.put("/api/admin/reservations/:id", authenticateAdmin, async (req, res) => {
  try {
    const reservationId = req.params.id
    const { status } = req.body

    if (!["pending", "confirmed", "cancelled"].includes(status)) {
      return res.status(400).json({ message: "Invalid status" })
    }

    await db.execute("UPDATE reservations SET status = ? WHERE id = ?", [status, reservationId])

    res.json({
      success: true,
      message: "Reservation status updated successfully",
    })
  } catch (error) {
    console.error("Update reservation status error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Inventory Management Routes
app.get("/api/admin/inventory", authenticateAdmin, async (req, res) => {
  try {
    const [inventory] = await db.execute("SELECT * FROM inventory ORDER BY name")

    res.json({
      success: true,
      inventory,
    })
  } catch (error) {
    console.error("Get inventory error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

app.post("/api/admin/inventory", authenticateAdmin, async (req, res) => {
  try {
    const { name, category, currentStock, minStock, unit, supplier } = req.body

    const [result] = await db.execute(
      "INSERT INTO inventory (name, category, current_stock, min_stock, unit, supplier) VALUES (?, ?, ?, ?, ?, ?)",
      [name, category, currentStock, minStock, unit, supplier],
    )

    res.status(201).json({
      success: true,
      message: "Inventory item created successfully",
      itemId: result.insertId,
    })
  } catch (error) {
    console.error("Create inventory error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

app.put("/api/admin/inventory/:id", authenticateAdmin, async (req, res) => {
  try {
    const itemId = req.params.id
    const { name, category, currentStock, minStock, unit, supplier } = req.body

    await db.execute(
      "UPDATE inventory SET name = ?, category = ?, current_stock = ?, min_stock = ?, unit = ?, supplier = ? WHERE id = ?",
      [name, category, currentStock, minStock, unit, supplier, itemId],
    )

    res.json({
      success: true,
      message: "Inventory item updated successfully",
    })
  } catch (error) {
    console.error("Update inventory error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

app.delete("/api/admin/inventory/:id", authenticateAdmin, async (req, res) => {
  try {
    const itemId = req.params.id

    await db.execute("DELETE FROM inventory WHERE id = ?", [itemId])

    res.json({
      success: true,
      message: "Inventory item deleted successfully",
    })
  } catch (error) {
    console.error("Delete inventory error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Menu Management Routes (Admin)
app.get("/api/admin/menu", authenticateAdmin, async (req, res) => {
  try {
    const [menuItems] = await db.execute("SELECT * FROM menu_items ORDER BY category, name")

    res.json({
      success: true,
      menuItems,
    })
  } catch (error) {
    console.error("Get admin menu error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

app.post("/api/admin/menu", authenticateAdmin, async (req, res) => {
  try {
    const { name, description, category, price, imageUrl, available } = req.body

    const [result] = await db.execute(
      "INSERT INTO menu_items (name, description, category, price, image_url, available) VALUES (?, ?, ?, ?, ?, ?)",
      [name, description, category, price, imageUrl, available],
    )

    res.status(201).json({
      success: true,
      message: "Menu item created successfully",
      itemId: result.insertId,
    })
  } catch (error) {
    console.error("Create menu item error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

app.put("/api/admin/menu/:id", authenticateAdmin, async (req, res) => {
  try {
    const itemId = req.params.id
    const { name, description, category, price, imageUrl, available } = req.body

    await db.execute(
      "UPDATE menu_items SET name = ?, description = ?, category = ?, price = ?, image_url = ?, available = ? WHERE id = ?",
      [name, description, category, price, imageUrl, available, itemId],
    )

    res.json({
      success: true,
      message: "Menu item updated successfully",
    })
  } catch (error) {
    console.error("Update menu item error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

app.delete("/api/admin/menu/:id", authenticateAdmin, async (req, res) => {
  try {
    const itemId = req.params.id

    await db.execute("DELETE FROM menu_items WHERE id = ?", [itemId])

    res.json({
      success: true,
      message: "Menu item deleted successfully",
    })
  } catch (error) {
    console.error("Delete menu item error:", error)
    res.status(500).json({ message: "Internal server error" })
  }
})

// Catch-all route deve ser o último
app.get("*", (req, res) => {
  console.log(`🔄 Catch-all route hit for: ${req.url}`)
  res.sendFile(path.join(__dirname, "../index.html"))
})

// Start server
async function startServer() {
  await initDatabase()

  app.listen(PORT, () => {
    console.log(`🚀 Server running on port ${PORT}`)
    console.log(`🌐 Visit http://localhost:${PORT} to view the website`)
    console.log(`👨‍💼 Admin panel: http://localhost:${PORT}/admin-login.html`)
    console.log(`📁 Static files served from: ${path.join(__dirname, "../")}`)
  })
}

startServer().catch(console.error)
