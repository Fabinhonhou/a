require("dotenv").config()
const mysql = require("mysql2/promise")

async function addSampleReservations() {
  console.log("=== ADICIONANDO RESERVAS DE EXEMPLO ===")

  try {
    // Conectar ao banco de dados
    const db = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "MYdatabase@2025",
      database: process.env.DB_NAME || "santoros_restaurant",
    })

    console.log("✅ Conectado ao banco de dados")

    // Verificar se há usuários no sistema
    const [users] = await db.execute("SELECT id, name, email FROM users")

    if (users.length === 0) {
      console.log("❌ Nenhum usuário encontrado. Crie uma conta primeiro.")
      return
    }

    console.log("Usuários disponíveis:")
    users.forEach((user, index) => {
      console.log(`${index + 1}. ID: ${user.id}, Nome: ${user.name}, Email: ${user.email}`)
    })

    // Usar o primeiro usuário para as reservas de exemplo
    const userId = users[0].id
    console.log(`\nUsando usuário ID ${userId} (${users[0].email}) para criar reservas de exemplo`)

    // Datas para as reservas (hoje, amanhã, próxima semana)
    const today = new Date()
    const tomorrow = new Date(today)
    tomorrow.setDate(tomorrow.getDate() + 1)
    const nextWeek = new Date(today)
    nextWeek.setDate(nextWeek.getDate() + 7)

    // Formatar datas para MySQL (YYYY-MM-DD)
    const formatDate = (date) => {
      return date.toISOString().split("T")[0]
    }

    // Reservas de exemplo
    const sampleReservations = [
      {
        user_id: userId,
        name: users[0].name,
        email: users[0].email,
        phone: "(555) 123-4567",
        date: formatDate(today),
        time: "19:00",
        guests: 2,
        special_requests: "Mesa próxima à janela",
        status: "confirmed",
      },
      {
        user_id: userId,
        name: users[0].name,
        email: users[0].email,
        phone: "(555) 123-4567",
        date: formatDate(tomorrow),
        time: "20:30",
        guests: 4,
        special_requests: "Aniversário",
        status: "pending",
      },
      {
        user_id: userId,
        name: users[0].name,
        email: users[0].email,
        phone: "(555) 123-4567",
        date: formatDate(nextWeek),
        time: "18:00",
        guests: 6,
        special_requests: "Preferência por mesa externa",
        status: "pending",
      },
    ]

    // Inserir reservas
    console.log("\nInserindo reservas de exemplo...")

    for (const reservation of sampleReservations) {
      const [result] = await db.execute(
        `INSERT INTO reservations 
         (user_id, name, email, phone, date, time, guests, special_requests, status) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          reservation.user_id,
          reservation.name,
          reservation.email,
          reservation.phone,
          reservation.date,
          reservation.time,
          reservation.guests,
          reservation.special_requests,
          reservation.status,
        ],
      )

      console.log(`✅ Reserva criada com ID: ${result.insertId} para ${reservation.date} às ${reservation.time}`)
    }

    // Verificar reservas
    const [reservations] = await db.execute(
      "SELECT id, date, time, guests, status FROM reservations WHERE user_id = ?",
      [userId],
    )

    console.log(`\nTotal de ${reservations.length} reservas para o usuário ${userId}:`)
    reservations.forEach((res) => {
      console.log(`- ID: ${res.id}, Data: ${res.date}, Hora: ${res.time}, Status: ${res.status}`)
    })

    await db.end()
    console.log("\n✅ RESERVAS DE EXEMPLO ADICIONADAS COM SUCESSO!")
    console.log("Agora você pode acessar o dashboard para ver suas reservas.")
  } catch (error) {
    console.error("\n❌ ERRO:", error.message)
    console.error(error)
  }
}

addSampleReservations().catch(console.error)
