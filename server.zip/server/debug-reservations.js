require("dotenv").config()
const mysql = require("mysql2/promise")
const jwt = require("jsonwebtoken")

const JWT_SECRET = process.env.JWT_SECRET || "b6203381221684dfc0504aa5bfeaa9e06ed7434ba146f02c54480b45ad785180"

async function debugReservations() {
  console.log("=== DIAGNÓSTICO COMPLETO DE RESERVAS ===")

  try {
    // Conectar ao banco de dados
    const db = await mysql.createConnection({
      host: process.env.DB_HOST || "localhost",
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || "root",
      password: process.env.DB_PASSWORD || "MYdatabase@2025",
      database: process.env.DB_NAME || "santoros_restaurant",
    })

    console.log("✅ Conectado ao banco de dados")

    // 1. Verificar usuários
    console.log("\n1. VERIFICANDO USUÁRIOS:")
    const [users] = await db.execute("SELECT id, name, email, created_at FROM users")
    console.log(`Encontrados ${users.length} usuários:`)
    users.forEach((user) => {
      console.log(`   - ID: ${user.id}, Nome: ${user.name}, Email: ${user.email}`)
    })

    if (users.length === 0) {
      console.log("❌ Nenhum usuário encontrado! Crie uma conta primeiro.")
      return
    }

    // 2. Verificar todas as reservas
    console.log("\n2. VERIFICANDO TODAS AS RESERVAS:")
    const [allReservations] = await db.execute(`
      SELECT r.*, u.name as user_name, u.email as user_email 
      FROM reservations r 
      LEFT JOIN users u ON r.user_id = u.id 
      ORDER BY r.created_at DESC
    `)

    console.log(`Encontradas ${allReservations.length} reservas no total:`)
    allReservations.forEach((res) => {
      console.log(
        `   - ID: ${res.id}, User ID: ${res.user_id}, Nome: ${res.name}, Data: ${res.date}, Status: ${res.status}`,
      )
    })

    // 3. Testar token JWT para cada usuário
    console.log("\n3. TESTANDO TOKENS JWT:")
    for (const user of users) {
      const token = jwt.sign({ userId: user.id, email: user.email }, JWT_SECRET, { expiresIn: "7d" })
      console.log(`   - Usuário ${user.id} (${user.email}): Token gerado`)

      // Verificar token
      try {
        const decoded = jwt.verify(token, JWT_SECRET)
        console.log(`     ✅ Token válido - User ID: ${decoded.userId}`)
      } catch (error) {
        console.log(`     ❌ Token inválido: ${error.message}`)
      }
    }

    // 4. Simular busca de reservas para cada usuário
    console.log("\n4. SIMULANDO BUSCA DE RESERVAS POR USUÁRIO:")
    for (const user of users) {
      const [userReservations] = await db.execute(
        `
        SELECT id, date, time, guests, status, special_requests, created_at 
        FROM reservations 
        WHERE user_id = ? 
        ORDER BY date ASC
      `,
        [user.id],
      )

      console.log(`   - Usuário ${user.id} (${user.email}): ${userReservations.length} reservas`)
      userReservations.forEach((res) => {
        console.log(`     * ID: ${res.id}, Data: ${res.date}, Hora: ${res.time}, Status: ${res.status}`)
      })
    }

    // 5. Criar uma reserva de teste se não houver nenhuma
    if (allReservations.length === 0) {
      console.log("\n5. CRIANDO RESERVA DE TESTE:")
      const userId = users[0].id
      const today = new Date().toISOString().split("T")[0]

      const [result] = await db.execute(
        `
        INSERT INTO reservations (user_id, name, email, phone, date, time, guests, special_requests, status) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'confirmed')
      `,
        [userId, users[0].name, users[0].email, "(555) 123-4567", today, "19:00", 2, "Teste de reserva"],
      )

      console.log(`   ✅ Reserva de teste criada com ID: ${result.insertId}`)
    }

    // 6. Verificar estrutura da tabela reservations
    console.log("\n6. ESTRUTURA DA TABELA RESERVATIONS:")
    const [columns] = await db.execute("DESCRIBE reservations")
    columns.forEach((col) => {
      console.log(`   - ${col.Field}: ${col.Type} ${col.Null === "NO" ? "NOT NULL" : "NULL"}`)
    })

    await db.end()
    console.log("\n✅ DIAGNÓSTICO CONCLUÍDO!")
  } catch (error) {
    console.error("\n❌ ERRO NO DIAGNÓSTICO:", error.message)
    console.error(error)
  }
}

debugReservations().catch(console.error)
